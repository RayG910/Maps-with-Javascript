

const express = require('express');
const router = express.Router();
const geo = require('node-geocoder');
const geocoder = geo({ provider: 'openstreetmap' });



router.get('/', async (req, res) => {
    const places = await req.db.findPlaces();
    res.json({ places: places });
    
});


    
router.put('/', async (req, res) => {
    const id = await req.db.createPlace(req.body.label, req.body.address, req.body.lat, req.body.long);
    
    res.json({ 
    id: id, 
    label: req.body.label, 
    address: req.body.address, 
    lat: req.body.lat, 
    long: req.body.long 
    
});
    const result = await geocoder.geocode(req.body.address);
    if (result.length > 0) {
    console.log(`The location of ${req.body.address} is ${result[0].latitude},${result[0].longitude}`);
    };   
    

});

router.delete('/:id', async (req, res) => {
    await req.db.deletePlace(req.params.id);
    res.status(200).send();
})

module.exports = router;


/* const map = L.map('map').setView([41, -74], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map); */ 

/* I receive an 'L is not defined error when I try to include the code snippet from line 45-49
throughout this page. I understand it's globally called for a fast initialization,
though I think the issue starts in layout.pug (commented out issues starting there) */
